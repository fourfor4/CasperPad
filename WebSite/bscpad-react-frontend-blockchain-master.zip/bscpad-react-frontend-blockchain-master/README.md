# BSCPad Binance Smart Chain Network
**BSCPad Binance Smart Chain Network** is a frontend with no backend written in React.js.

### Prerequisites

 * We assume that you have up-to-date Node.js version installed.
 
### Installing
#### Manual

 * yarn install
 * yarn start
 If you make changes to code, your pages will automatically reload.
 
## Live URL
Demo: https://bscpad-react-frontend-blockchain.vercel.app/

## License

This project is licensed under the GIT License.
