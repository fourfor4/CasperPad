import React from 'react';

export default function Background() {
    return (
        <div className="background">
        </div>
    )
}