import { } from '../types';

const initialState = {};

export default function dataReducer(state = initialState, action) {
    switch (action.type) {
        default:
            return state;
    }
}