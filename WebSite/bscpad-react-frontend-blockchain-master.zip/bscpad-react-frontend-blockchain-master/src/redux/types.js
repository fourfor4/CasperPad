// ui loading reducer types
export const SET_LOADING = 'SET_LOADING';
export const STOP_LOADING = 'STOP_LOADING';